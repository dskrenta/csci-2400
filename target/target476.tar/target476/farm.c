/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_249(unsigned x)
{
    return x + 2428996424U;
}

unsigned getval_465()
{
    return 2425393240U;
}

unsigned addval_159(unsigned x)
{
    return x + 3351857292U;
}

void setval_479(unsigned *p)
{
    *p = 1657245784U;
}

unsigned addval_231(unsigned x)
{
    return x + 2425393176U;
}

void setval_165(unsigned *p)
{
    *p = 3281031256U;
}

void setval_145(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_452(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_196()
{
    return 3375415945U;
}

unsigned getval_117()
{
    return 3348156041U;
}

void setval_486(unsigned *p)
{
    *p = 2428668309U;
}

unsigned getval_194()
{
    return 2430634056U;
}

unsigned addval_476(unsigned x)
{
    return x + 3685011081U;
}

unsigned addval_493(unsigned x)
{
    return x + 3223372417U;
}

unsigned getval_399()
{
    return 3682127497U;
}

unsigned getval_285()
{
    return 3515446198U;
}

unsigned addval_272(unsigned x)
{
    return x + 3674788237U;
}

void setval_443(unsigned *p)
{
    *p = 3224945293U;
}

unsigned addval_140(unsigned x)
{
    return x + 3524841097U;
}

void setval_125(unsigned *p)
{
    *p = 2425668233U;
}

unsigned getval_153()
{
    return 3286272332U;
}

unsigned addval_238(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_256()
{
    return 3674788233U;
}

unsigned getval_345()
{
    return 3222848137U;
}

unsigned addval_275(unsigned x)
{
    return x + 2429655406U;
}

unsigned getval_416()
{
    return 2425672073U;
}

unsigned addval_119(unsigned x)
{
    return x + 2430634824U;
}

unsigned getval_430()
{
    return 3586314633U;
}

unsigned addval_347(unsigned x)
{
    return x + 3285093316U;
}

void setval_215(unsigned *p)
{
    *p = 3263796995U;
}

unsigned getval_388()
{
    return 3286272456U;
}

unsigned addval_304(unsigned x)
{
    return x + 2429454678U;
}

unsigned addval_266(unsigned x)
{
    return x + 2425668233U;
}

void setval_258(unsigned *p)
{
    *p = 2446231911U;
}

void setval_407(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_134(unsigned x)
{
    return x + 3281179017U;
}

unsigned getval_293()
{
    return 2425541001U;
}

void setval_336(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_480()
{
    return 2447411528U;
}

unsigned addval_495(unsigned x)
{
    return x + 3682913929U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
